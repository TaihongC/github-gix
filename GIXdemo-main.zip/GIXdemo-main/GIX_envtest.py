import sys
import numpy as np

print("Python version: "+sys.version)
print("Numpy version: "+np.__version__)
